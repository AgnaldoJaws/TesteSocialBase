/*definição do controller*/
	post
		.controller('PostCtlr',				
				['$scope','PostSrv',
				 function($scope, PostSrv){
					
				$scope.nome = "Agnaldo";
				$scope.load = function () {
					$scope.registros = PostSrv.query();
				}
				$scope.load();
				}
			]
		);